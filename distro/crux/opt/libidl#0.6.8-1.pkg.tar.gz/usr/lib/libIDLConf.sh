#
# Configuration file for using the libIDL library in GNOME applications
#
LIBIDL_INCLUDEDIR="-I/usr/include/glib-1.2 -I/usr/lib/glib/include -I/usr/include"
LIBIDL_LIBDIR="-L/usr/lib"
LIBIDL_LIBS="-lIDL -L/usr/lib -lglib"
MODULE_VERSION="libIDL-0.6.8"