# These are some common functions for our scripts

ALPHA_IP=192.168.217.1
BETA_IP=192.168.217.2

run_command ()
{
	echo "Executing command $1"
	$1
	if [ $? != "0" ] ; then
		echo "Error executing command $1"
		exit 1
	fi
}

get_basename ()
{
	echo "Obtaining basename for package $1"
	BASENAME=`echo $1 | sed "s:^.*/::"`
	BASENAME=`echo $BASENAME | cut -d \# -f 1`
}

get_other_private_ip ()
{
	if [ "ifconfig | grep $ALPHA_IP" ] ; then
		OTHER_IP=$BETA_IP
	else
		OTHER_IP=$ALPHA_IP
	fi
}

get_primary_hostname ()
{
	PRIMARY_HOSTNAME=`cat /etc/snapptix.conf | grep "^1 " | cut -d \  -f 2`
	if [ -z "$PRIMARY_HOSTNAME" ] ; then
		echo "Didn't get a primary hostname"
		exit 1
	fi
}

get_primary_ip ()
{
	PRIMARY_IP=`cat /etc/snapptix.conf | grep "^1 " | cut -d \  -f 3`
	if [ -z "$PRIMARY_IP" ] ; then
		echo "Didn't get a primary IP"
		exit 1
	fi
}

get_primary_device ()
{
	PRIMARY_DEVICE=`cat /etc/snapptix.conf | grep "^1 " | cut -d \  -f 4`
	if [ -z "$PRIMARY_DEVICE" ] ; then
		echo "Didn't get a primary device"
		exit 1
	fi
}

get_primary_subnet ()
{
	PRIMARY_SUBNET=`cat /etc/snapptix.conf | grep "^S " | cut -d \  -f 2`
	if [ -z "$PRIMARY_SUBNET" ] ; then
		echo "Didn't get a primary subnet"
		exit 1
	fi
}

get_primary_gateway ()
{
	PRIMARY_GATEWAY=`cat /etc/snapptixconf | grep "^G " | cut -d \  -f 2`
	if [ -z "$PRIMARY_GATEWAY" ] ; then
		echo "Didn't get a primary gateway"
		exit 1
	fi
}

get_secondary_ip ()
{
	SECONDARY_IP=`cat /etc/snapptix.conf | grep "^2 " | cut -d \  -f 3`
	if [ -z "$SECONDARY_IP" ] ; then
		echo "Didn't get a secondary IP"
		exit 1
	fi
}

get_secondary_device ()
{
	SECONDARY_DEVICE=`cat /etc/snapptix.conf | grep "^2 " | cut -d \  -f 4`
	if [ -z "$SECONDARY_DEVICE" ] ; then
		echo "Didn't get a secondary device"
		exit 1
	fi
}

get_secondary_subnet ()
{
	SECONDARY_SUBNET=`cat /etc/snapptix.conf | grep "^S " | cut -d \  -f 3`
	if [ -z "$SECONDARY_SUBNET" ] ; then
		echo "Didn't get a secondary subnet"
		exit 1
	fi
}

get_secondary_gateway ()
{
	SECONDARY_GATEWAY=`cat /etc/snapptixconf | grep "^G " | cut -d \  -f 3`
	if [ -z "$SECONDARY_GATEWAY" ] ; then
		echo "Didn't get a secondary gateway"
		exit 1
	fi
}

get_primary_dns ()
{
	PRIMARY_DNS1=`cat /etc/snapptix.conf | grep "^DNS1 " | cut -d \  -f 2`
	if [ -z "$PRIMARY_DNS1" ] ; then
		echo "Didn't get primary DNS 1"
		exit 1
	fi
	PRIMARY_DNS2=`cat /etc/snapptix.conf | grep "^DNS1 " | cut -d \  -f 3`
}

get_secondary_dns ()
{
	SECONDARY_DNS1=`cat /etc/snapptix.conf | grep "^DNS2 " | cut -d \  -f 2`
	if [ -z "$SECONDARY_DNS1" ] ; then
		echo "Didn't get primary DNS 2"
		exit 1
	fi
	SECONDARY_DNS2=`cat /etc/snapptix.conf | grep "^DNS2 " | cut -d \  -f 3`
}

get_cluster_ip ()
{
	CLUSTER_IP=`cat /etc/snapptix.conf | grep "^P " | cut -d \  -f 3`
	if [ -z "$CLUSTER_IP" ] ; then
		echo "Didn't get cluster IP"
		exit 1
	fi
}
