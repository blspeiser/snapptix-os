#!/bin/bash
# This script reads /etc/snapptix.conf and sets up the
# net files accordingly

. /usr/share/snapptix/snapptix_functions.sh

get_primary_hostname
get_cluster_ip

CHECK_ALPHA=`ifconfig | grep $ALPHA_IP`

# Edit haresources
cat /etc/ha.d/haresources | sed "s:$PRIMARY_HOSTNAME [0123456789\.]*:$PRIMARY_HOSTNAME $CLUSTER_IP:" > /etc/ha.d/haresources.new
mv /etc/ha.d/haresources.new /etc/ha.d/haresources

# Edit resolv.conf
if [ "$CHECK_ALPHA" ] ; then
	get_primary_dns
	echo "nameserver $PRIMARY_DNS1" > /etc/resolv.conf.1
	if [ "$PRIMARY_DNS2" != "___.___.___.___" ] ; then
		echo "nameserver $PRIMARY_DNS2" >> /etc/resolv.conf.1
	fi
else
	get_secondary_dns
	echo "nameserver $SECONDARY_DNS1" > /etc/resolv.conf.2
	if [ "$SECONDARY_DNS2" != "___.___.___.___" ] ; then
		echo "nameserver $SECONDARY_DNS2" >> /etc/resolv.conf.2
	fi
fi

# Edit /etc/rc.d/net
if [ "$CHECK_ALPHA" ] ; then
	get_primary_ip
	get_primary_device
	get_primary_subnet
	get_primary_gateway
	echo "ALPHA - $PRIMARY_IP $PRIMARY_DEVICE $PRIMARY_SUBNET $PRIMARY_GATEWAY"
	if [ $PRIMARY_SUBNET != "___.___.___.___" ] ; then
		sed -i "s:ifconfig $PRIMARY_DEVICE.*:ifconfig $PRIMARY_DEVICE inet $PRIMARY_IP netmask $PRIMARY_SUBNET:" /etc/rc.d/net
	else
		sed -i "s:ifconfig $PRIMARY_DEVICE.*:ifconfig $PRIMARY_DEVICE inet $PRIMARY_IP:" /etc/rc.d/net
	fi
	if [ $PRIMARY_GATEWAY != "___.___.___.___" ] ; then
		sed -i "s:route add default gw.*:route add default gw $PRIMARY_GATEWAY dev $PRIMARY_DEVICE:" /etc/rc.d/net
	fi
else
	get_secondary_ip
	get_secondary_device
	get_secondary_subnet
	get_secondary_gateway
	echo "BETA - $SECONDARY_IP $SECONDARY_DEVICE $SECONDARY_SUBNET $SECONDARY_GATEWAY"
	if [ $SECONDARY_SUBNET != "___.___.___.___" ] ; then
		sed -i "s:ifconfig $SECONDARY_DEVICE.*:ifconfig $SECONDARY_DEVICE inet $SECONDARY_IP netmask $SECONDARY_SUBNET:" /etc/rc.d/net
	else
		sed -i "s:ifconfig $SECONDARY_DEVICE.*:ifconfig $SECONDARY_DEVICE inet $SECONDARY_IP:" /etc/rc.d/net
	fi
	if [ $SECONDARY_GATEWAY != "___.___.___.___" ] ; then
		sed -i "s:route add default gw.*:route add default gw $SECONDARY_GATEWAY dev $SECONDARY_DEVICE:" /etc/rc.d/net
	fi
fi

# Restart the heartbeat and net
/etc/rc.d/heartbeat stop
/etc/rc.d/net stop
/etc/rc.d/net start
/etc/rc.d/heartbeat start
