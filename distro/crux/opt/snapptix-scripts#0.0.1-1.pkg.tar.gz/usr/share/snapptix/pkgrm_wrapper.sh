#!/bin/bash

. /usr/share/snapptix/snapptix_functions.sh

if [ -z "$1" ] ; then
	echo "Usage is $0 <package_name>"
	exit 1
fi
get_basename "$1"

# Add the package
run_command "pkgrm $1"
# Run the install script
run_command "/usr/share/snapptix/packages/$BASENAME.uninstall"
# Sync the other node
run_command "/usr/share/snapptix/sync_root.sh"
exit 0
