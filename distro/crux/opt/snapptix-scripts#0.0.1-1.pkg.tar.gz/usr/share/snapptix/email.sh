#!/bin/sh

. /usr/share/snapptix/snapptix_functions.sh

if [ ! -f /usr/share/Janix/JavaEmail.mail ] ; then
	echo "Email file not found"
	exit 1
fi
run_command "cat /usr/share/Janix/JavaEmail.mail | /var/qmail/bin/qmail-inject"
run_command "rm /usr/share/Janix/JavaEmail.mail"
exit 0
