#!/bin/bash
# This script syncs the other node with this one

. /usr/share/snapptix/snapptix_functions.sh

get_other_private_ip

# Sync the other node if were not Alpha only
MAXNODES=`grep "^maxnodes" /etc/node.conf | cut -d \  -f 2`
if [ "$MAXNODES" != "1" ] ; then
	run_command "/usr/bin/rsync --timeout=10 --exclude-from /etc/rsyncd.exclude -avz / $OTHER_IP::root"
fi
exit 0
