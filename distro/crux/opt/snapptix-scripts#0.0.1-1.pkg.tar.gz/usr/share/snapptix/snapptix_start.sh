#!/bin/sh
# This script is run from /etc/rc
# it starts everything Snapptix

PATH=$PATH:/usr/X11R6/bin

/usr/bin/Janix /var/log/janix.log &
xinit /usr/j2re1.4.1_02/bin/java -jar /usr/share/snapptix/jar/snapptix_gui.jar -- vt7
