#ifndef __ROMFS_FS_SB
#define __ROMFS_FS_SB

/* romfs superblock in-core data */

struct romfs_sb_info {
	unsigned long s_maxsize;
};

#endif
