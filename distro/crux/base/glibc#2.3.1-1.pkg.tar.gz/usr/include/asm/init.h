#error "<asm/init.h> should never be used - use <linux/init.h> instead"
